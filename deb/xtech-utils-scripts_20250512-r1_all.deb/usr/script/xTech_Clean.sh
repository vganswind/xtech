#!/bin/sh

#         _____         _                      _
#   __  _|_   _|__  ___| |__    ___ ___   ___ | |
#   \ \/ / | |/ _ \/ __| '_ \  / __/ _ \ / _ \| |
#    >  <  | |  __/ (__| | | || (_| (_) | (_) | |
#   /_/\_\ |_|\___|\___|_| |_(_)___\___/ \___/|_|
#
# xTech_Clean.sh

# # # # # # # # # # # # # # # # # # #
#
# System ermitteln
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/apt/sources.list.d ]; then
  EXEC_CMD="apt -y"
  EXEC_LISTINSTALLED="dpkg-query -l"
else
  EXEC_CMD="opkg"
  EXEC_LISTINSTALLED="$EXEC_CMD list-installed"
fi


# # # # # # # # # # # # # # # # # # #
#
# Konfigurationswerte des Skripts
#
# # # # # # # # # # # # # # # # # # #
pkgs=""


# # # # # # # # # # # # # # # # # # #
#
# Aktualisierungen abgerufen
#
# # # # # # # # # # # # # # # # # # #
echo "Die Aktualisierungen werden abgerufen ..."
${EXEC_CMD} update

echo ""
echo "Die Box wird jetzt von allem was von xTech kommt bereinigt."


# # # # # # # # # # # # # # # # # # #
#
# xstreamity Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/enigma2/xstreamity/playlists.txt ]; then
  echo "Bereinigung der xstreamity playlists"
  rm -f /etc/enigma2/xstreamity/playlists.txt
  rm -f /etc/enigma2/xstreamity/x-playlists.json
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-extensions-xstreamity)" ]; then
  pkgs="$pkgs enigma2-plugin-extensions-xstreamity"
fi


# # # # # # # # # # # # # # # # # # #
#
# Jedi Maker Xtream Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/enigma2/jediplaylists/playlists.txt ]; then
  echo "Bereinigung der jedimakerxtream playlists"
  rm -f /etc/enigma2/jediplaylists/playlists.txt
  rm -f /etc/enigma2/jediplaylists/playlist_all_new.json
  rm -f /etc/enigma2/userbouquet.jedimakerxtream_*
  sed -i '/jedimakerxtream/d' /etc/enigma2/bouquets.tv
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-extensions-jedimakerxtream)" ]; then
  pkgs="$pkgs enigma2-plugin-extensions-jedimakerxtream"
fi


# # # # # # # # # # # # # # # # # # #
#
# Bouquet Maker Xtream Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/enigma2/bouquetmakerxtream/playlists.txt ]; then
  echo "Bereinigung der bouquetmakerxtream playlists"
  rm -f /etc/enigma2/bouquetmakerxtream/playlists.txt
  rm -f /etc/enigma2/bouquetmakerxtream/bmx_playlists.json
  rm -f /etc/enigma2/userbouquet.bouquetmakerxtream_*
  sed -i '/bouquetmakerxtream/d' /etc/enigma2/bouquets.tv
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-extensions-bouquetmakerxtream)" ]; then
  pkgs="$pkgs enigma2-plugin-extensions-bouquetmakerxtream"
fi


# # # # # # # # # # # # # # # # # # #
#
# Senderlisten Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtech)" ]; then
  pkgs="${pkgs} enigma2-plugin-userbouquet-xtech"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechpyur)" ]; then
  pkgs="${pkgs} enigma2-plugin-userbouquet-xtechpyur"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechextended)" ]; then
  pkgs="${pkgs} enigma2-plugin-userbouquet-xtechextended"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechextendedpyur)" ]; then
  pkgs="${pkgs} enigma2-plugin-userbouquet-xtechextendedpyur"
fi


# # # # # # # # # # # # # # # # # # #
#
# Oscam Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-softcams-xtech)" ]; then
  pkgs="$pkgs enigma2-plugin-softcams-xtech"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-softcams-xtechemu)" ]; then
  pkgs="$pkgs enigma2-plugin-softcams-xtechemu"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-softcams-xtech-beta)" ]; then
  pkgs="$pkgs enigma2-plugin-softcams-xtech-beta"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-softcams-oscam-all-images)" ]; then
  pkgs="$pkgs enigma2-softcams-oscam-all-images"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-settings-xtech)" ]; then
  pkgs="$pkgs enigma2-plugin-settings-xtech"
fi


# # # # # # # # # # # # # # # # # # #
#
# Tools Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -n "$($EXEC_LISTINSTALLED | grep xtech-utils-scripts)" ]; then
  pkgs="$pkgs xtech-utils-scripts"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-extensions-epgimport)" ]; then
  pkgs="$pkgs enigma2-plugin-extensions-epgimport"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-extensions-EPGImport-mod-dorik1972)" ]; then
  pkgs="$pkgs enigma2-plugin-extensions-EPGImport-mod-dorik1972"
fi


# # # # # # # # # # # # # # # # # # #
#
# Löschen der picons
#
# # # # # # # # # # # # # # # # # # #
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-picons-xtech)" ]; then
  pkgs="$pkgs enigma2-plugin-picons-xtech"
fi


# # # # # # # # # # # # # # # # # # #
#
# Feed Deinstallieren
#
# # # # # # # # # # # # # # # # # # #
if [ -n "$($EXEC_LISTINSTALLED | grep xtech-feed-conf)" ]; then
  pkgs="$pkgs xtech-feed-conf"
fi


# # # # # # # # # # # # # # # # # # #
#
# Deinstallation der Pakete
#
# # # # # # # # # # # # # # # # # # #
opkg remove --force-removal-of-dependent-packages $pkgs


# # # # # # # # # # # # # # # # # # #
#
# Löschen von diversen Dateien
#
# # # # # # # # # # # # # # # # # # #
rm -rf /etc/tuxbox/config/oscamxtechicam/
rm -rf /etc/tuxbox/config/oscamxtechicam-beta/
rm -rf /etc/tuxbox/config_old/
rm -f /etc/xtechpicon.conf
rm -f /etc/xtech.conf

# # # # # # # # # # # # # # # # # # #
#
# Neustarten
#
# # # # # # # # # # # # # # # # # # #
echo ""
echo Der Neustart wird jetzt ausgeführt ...
init 6
