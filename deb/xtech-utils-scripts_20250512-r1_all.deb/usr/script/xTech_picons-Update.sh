#!/bin/sh

#         _____         _                      _
#   __  _|_   _|__  ___| |__    ___ ___   ___ | |
#   \ \/ / | |/ _ \/ __| '_ \  / __/ _ \ / _ \| |
#    >  <  | |  __/ (__| | | || (_| (_) | (_) | |
#   /_/\_\ |_|\___|\___|_| |_(_)___\___/ \___/|_|
#
# xTech_picons-Update.sh

if [ ! -e /etc/xtechpicon.conf ]; then
  echo Die Konfiguration für den picon-Download existiert nicht!!
  echo Bitte zuerst diesen per Terminal und dem Install-Skript einrichten
  exit
fi

# # # # # # # # # # # # # # # # # # #
#
# Aktualisierungen abgerufen
#
# # # # # # # # # # # # # # # # # # #
wget -qO- https://xtech.cool/script/picons.sh | RUNNING=cron bash
