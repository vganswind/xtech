#!/bin/sh

#         _____         _                      _
#   __  _|_   _|__  ___| |__    ___ ___   ___ | |
#   \ \/ / | |/ _ \/ __| '_ \  / __/ _ \ / _ \| |
#    >  <  | |  __/ (__| | | || (_| (_) | (_) | |
#   /_/\_\ |_|\___|\___|_| |_(_)___\___/ \___/|_|
#
# xTech_Senderlisten-Update.sh

# # # # # # # # # # # # # # # # # # #
#
# System ermitteln
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/apt/sources.list.d ]; then
  EXEC_CMD="apt -y"
  EXEC_LISTINSTALLED="dpkg-query -l"
else
  EXEC_CMD="opkg"
  EXEC_LISTINSTALLED="$EXEC_CMD list-installed"
fi

# # # # # # # # # # # # # # # # # # #
#
# Aktualisierungen abgerufen
#
# # # # # # # # # # # # # # # # # # #
echo Die Aktualisierungen werden abgerufen ...
${EXEC_CMD} update

# # # # # # # # # # # # # # # # # # #
#
# Senderlisten prüfen
#
# # # # # # # # # # # # # # # # # # #
echo ""
echo Aktualisieren der Senderlisten ...
pkg=""

if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtech)" ]; then
  pkg="${pkg} enigma2-plugin-userbouquet-xtech"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechpyur)" ]; then
  pkg="${pkg} enigma2-plugin-userbouquet-xtechpyur"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechextended)" ]; then
  pkg="${pkg} enigma2-plugin-userbouquet-xtechextended"
fi
if [ -n "$($EXEC_LISTINSTALLED | grep enigma2-plugin-userbouquet-xtechextendedpyur)" ]; then
  pkg="${pkg} enigma2-plugin-userbouquet-xtechextendedpyur"
fi

# # # # # # # # # # # # # # # # # # #
#
# Senderlisten installieren
#
# # # # # # # # # # # # # # # # # # #
if [ -z "${pkg}" ]; then
  echo ";) Es wurden keine Senderlisten gefunden! ";
else
  $EXEC_CMD install --force-reinstall ${pkg}
fi
