#!/bin/sh

#         _____         _                      _
#   __  _|_   _|__  ___| |__    ___ ___   ___ | |
#   \ \/ / | |/ _ \/ __| '_ \  / __/ _ \ / _ \| |
#    >  <  | |  __/ (__| | | || (_| (_) | (_) | |
#   /_/\_\ |_|\___|\___|_| |_(_)___\___/ \___/|_|
#
# xTech_Box-Update.sh

# # # # # # # # # # # # # # # # # # #
#
# System ermitteln
#
# # # # # # # # # # # # # # # # # # #
if [ -e /etc/apt/sources.list.d ]; then
  EXEC_CMD="apt -y"
else
  EXEC_CMD="opkg"
fi

# # # # # # # # # # # # # # # # # # #
#
# Aktualisierungen abgerufen und installiert
#
# # # # # # # # # # # # # # # # # # #
echo Die Aktualisierungen werden abgerufen und installiert ...
${EXEC_CMD} update && ${EXEC_CMD} upgrade

# # # # # # # # # # # # # # # # # # #
#
# Neustarten
#
# # # # # # # # # # # # # # # # # # #
echo ""
echo Der Neustart wird jetzt ausgeführt ...
init 6
